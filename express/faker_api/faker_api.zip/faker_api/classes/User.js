const { faker } = require('@faker-js/faker');
// import { faker } from '@faker-js/faker';

class User {
  constructor() {}
}
