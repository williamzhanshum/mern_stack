import './App.css';
import UserForm from './components/UserdForm';

function App() {
  return (
    <div className='App'>
      <UserForm />
    </div>
  );
}

export default App;
