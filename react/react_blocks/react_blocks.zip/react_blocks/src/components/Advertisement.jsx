import React, { Component } from 'react';
import styles from './Components.module.css';

class Advertisement extends Component {
  render() {
    return <div className={styles.advertisement}></div>;
  }
}

export default Advertisement;
