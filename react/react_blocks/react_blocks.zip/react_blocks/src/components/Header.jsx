import React, { Component } from 'react';
// import './Header.css';
import styles from './Components.module.css';

class Header extends Component {
  render() {
    return <div className={styles.header}></div>;
  }
}

export default Header;
