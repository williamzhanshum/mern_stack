import React, { Component } from 'react';
import styles from './Components.module.css';

class Navigation extends Component {
  render() {
    return <div className={styles.navigation}></div>;
  }
}

export default Navigation;
