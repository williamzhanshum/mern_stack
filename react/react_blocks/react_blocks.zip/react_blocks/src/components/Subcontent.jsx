import React, { Component } from 'react';
import styles from './Components.module.css';

class Subcontent extends Component {
  render() {
    return <div className={styles.subcontent}></div>;
  }
}

export default Subcontent;
