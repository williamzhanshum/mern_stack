import { useState } from 'react';

const TaskForm = (props) => {
  const [task, setTask] = useState('');

  const handleTaks = (e) => {
    e.preventDefault();
  };

  return <form></form>;
};
